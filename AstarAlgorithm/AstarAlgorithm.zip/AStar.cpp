#include "AStar.h"

void AStar::Init()
{
    for (int i = 0; i < 20; ++i)
    {
        for (int j = 0; j < 20; ++j)
        {
            Center[j][i] = { j * 50 + 25, i * 50 + 25 };
            StartToCur[j][i] = { Center[j][i].x - 23, Center[j][i].y - 23 };
            EndToCur[j][i] = { Center[j][i].x - 23, Center[j][i].y-10 };
            Total[j][i] = { Center[j][i].x - 23, Center[j][i].y+5 };
        }
    }
    memset(StartG, -1, sizeof(StartG[0][0]) * 20 * 20);
    memset(EndH, -1, sizeof(EndH[0][0]) * 20 * 20);
    memset(TotalF, -1, sizeof(TotalF[0][0]) * 20 * 20);
}

void AStar::DrawGHF_Text(HDC hdc)
{
    for (int i = 0; i < 20; ++i)
    {
        for (int j = 0; j < 20; ++j)
        {
            if (isClose[i][j] || isStart[i][j] || isEnd[i][j] || TotalF[i][j] == -1 || EndH[i][j] == -1)
                continue;
            wchar_t Sbuffer[256];
            wsprintfW(Sbuffer, L"G=%d", StartG[i][j]);
            TextOut(hdc, StartToCur[i][j].x, StartToCur[i][j].y, Sbuffer, _tcslen(Sbuffer));

            wchar_t Ebuffer[256];
            wsprintfW(Ebuffer, L"H=%d", EndH[i][j]);
            TextOut(hdc, EndToCur[i][j].x, EndToCur[i][j].y, Ebuffer, _tcslen(Ebuffer));

            wchar_t Tbuffer[256];
            wsprintfW(Tbuffer, L"F=%d", TotalF[i][j]);
            TextOut(hdc, Total[i][j].x, Total[i][j].y, Tbuffer, _tcslen(Tbuffer));
        }
    }
}

bool AStar::Set_FromStart_Position(int i, int j, queue<POINT>& path_Check)
{
    for (int k = i - 1; k <= i + 1; ++k)
    {
        if (k < 0 || k >= 20) // ������ ��� ��
            continue;

        for (int l = j - 1; l <= j + 1; ++l)
        {
            if (l < 0 || l >= 20 || (l == j && k == i)) // ������ ��� �� or 
                continue;
            if (isClose[k][l] || isVisited[k][l]) // ������ ��
                continue;
            if (this->isEnd[i][j])
                return true;

            if (abs(l - j) + abs(k - i) == 1) // �����¿�
            {
                if ((StartG[k][l] == -1) || (StartG[k][l] > StartG[i][j] + 10))
                {
                    StartG[k][l] = StartG[i][j] + 10;
                    path_Check.push(POINT{ k, l });
                }

            }
            else // �밢��
            {
                if ((StartG[k][l] == -1) || (StartG[k][l] > StartG[i][j] + 14))
                {
                    StartG[k][l] = StartG[i][j] + 14;
                    path_Check.push(POINT{ k, l });
                }
            }

            TotalF[k][l] = StartG[k][l] + EndH[k][l];
        }
    }

    for (int k = 0; k < path_Check.size(); ++k)
    {
        isVisited[path_Check.front().x][path_Check.front().y] = true;
        int x = path_Check.front().x;
        int y = path_Check.front().y;
        path_Check.pop();
        bool check = Set_FromStart_Position(x, y, Path_Check);
        if (check)
            return true;
    }
}

bool AStar::Set_FromEnd_Position(int i, int j, vector<POINT>& Path)
{
    queue<POINT> temp;

    for (int k = i - 1; k <= i + 1; ++k)
    {
        if (k < 0 || k >= 20) // ������ ��� ��
            continue;

        for (int l = j - 1; l <= j + 1; ++l)
        {
            if (l < 0 || l >= 20 || (l == j && k == i)) // ������ ��� ��
                continue;
            if (isClose[k][l] || !isVisited[k][l]) // ������ ��
                continue;

            if (TotalF[k][l] == 0)
                return true;

            if (abs(l - j) + abs(k - i) == 1) // �����¿�
            {
                if ((EndH[k][l] == -1) || (EndH[k][l] > EndH[i][j] + 10))
                {
                    EndH[k][l] = EndH[i][j] + 10;
                }
            }
            else // �밢��
            {
                if ((EndH[k][l] == -1) || (EndH[k][l] > EndH[i][j] + 14))
                {
                    EndH[k][l] = EndH[i][j] + 14;
                }
            }
            TotalF[k][l] = StartG[k][l] + EndH[k][l];

            if (temp.size() > 0)
            {
                if (TotalF[temp.front().x][temp.front().y] > TotalF[k][l])
                {
                    temp.pop();
                    temp.push(POINT{ k, l });
                }
                else if (TotalF[temp.front().x][temp.front().y] == TotalF[k][l])
                {
                    if (StartG[temp.front().x][temp.front().y] > StartG[k][l])
                    {
                        temp.pop();
                        temp.push(POINT{ k, l });
                    }
                }
            }
            else
                temp.push(POINT{ k, l });
        }
    }

    if (temp.size() > 2 || temp.size() == 0)
        int temph = 0;
    else
    {
        Path.push_back(temp.front());
        bool check = Set_FromEnd_Position(temp.front().x, temp.front().y, Path);
        if (check)
            return true;
        temp.pop();
    }
}
